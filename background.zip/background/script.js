const background = document.querySelector('.background');

const candies = ['🍬', '🍫', '🍭', '🍩', '🍪', '🎂', '🍰', '🧁']; // Emojis de doces

function createCandy() {
    const candy = document.createElement('div');
    candy.classList.add('candy');
    
    // Escolhe um emoji aleatório
    const randomCandy = candies[Math.floor(Math.random() * candies.length)];
    candy.textContent = randomCandy;
    
    // Tamanho aleatório entre 1rem e 3rem
    const size = Math.random() * 2 + 1;
    candy.style.fontSize = `${size}rem`;
    
    // Posição horizontal aleatória
    candy.style.left = `${Math.random() * 100}vw`;
    
    // Duração da animação (velocidade de queda)
    candy.style.animationDuration = `${Math.random() * 3 + 2}s`;
    
    // Adiciona o doce ao fundo
    background.appendChild(candy);
    
    // Remove o doce após a animação terminar
    setTimeout(() => {
        candy.remove();
    }, 5000); // Remove após 5 segundos
}

// Cria um novo doce a cada 300ms
setInterval(createCandy, 300);